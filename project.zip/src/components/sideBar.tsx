import Divider from "@mui/material/Divider";
import IconButton from "@mui/material/IconButton";
import ChevronLeftIcon from "@mui/icons-material/ChevronLeft";
import ChevronRightIcon from "@mui/icons-material/ChevronRight";
import ListItem from "@mui/material/ListItem";
import ListItemButton from "@mui/material/ListItemButton";
import ListItemIcon from "@mui/material/ListItemIcon";
import ListItemText from "@mui/material/ListItemText";
import MuiDrawer from "@mui/material/Drawer";
import List from "@mui/material/List";
import { styled, useTheme, Theme, CSSObject } from "@mui/material/styles";

import { grey } from "@mui/material/colors";

import HomeOutlinedIcon from "@mui/icons-material/HomeOutlined";
import {
  BarChartOutlined,
  CalendarTodayOutlined,
  ContactsOutlined,
  HelpOutlineOutlined,
  MapOutlined,
  PeopleOutline,
  PersonOutline,
  PieChartOutline,
  ReceiptOutlined,
  TimelineOutlined,
} from "@mui/icons-material";
import { Avatar, Typography } from "@mui/material";
import { useLocation, useNavigate } from "react-router-dom";
import Tooltip from "@mui/material/Tooltip";

const drawerWidth = 240;

const openedMixin = (theme: Theme): CSSObject => ({
  width: drawerWidth,
  transition: theme.transitions.create("width", {
    easing: theme.transitions.easing.sharp,
    duration: theme.transitions.duration.enteringScreen,
  }),
  overflowX: "hidden",
});

const closedMixin = (theme: Theme): CSSObject => ({
  transition: theme.transitions.create("width", {
    easing: theme.transitions.easing.sharp,
    duration: theme.transitions.duration.leavingScreen,
  }),
  overflowX: "hidden",
  width: `calc(${theme.spacing(7)} + 1px)`,
  [theme.breakpoints.up("sm")]: {
    width: `calc(${theme.spacing(8)} + 1px)`,
  },
});

const Drawer = styled(MuiDrawer, {
  shouldForwardProp: (prop) => prop !== "open",
})(({ theme }) => ({
  width: drawerWidth,
  flexShrink: 0,
  whiteSpace: "nowrap",
  boxSizing: "border-box",
  variants: [
    {
      props: ({ open }) => open,
      style: {
        ...openedMixin(theme),
        "& .MuiDrawer-paper": openedMixin(theme),
      },
    },
    {
      props: ({ open }) => !open,
      style: {
        ...closedMixin(theme),
        "& .MuiDrawer-paper": closedMixin(theme),
      },
    },
  ],
}));

const DrawerHeader = styled("div")(({ theme }) => ({
  display: "flex",
  alignItems: "center",
  justifyContent: "flex-end",
  padding: theme.spacing(0, 1),
  // necessary for content to be below app bar
  ...theme.mixins.toolbar,
}));

const part1 = [
  { icon: <HomeOutlinedIcon />, text: "Dashboard", link: "/" },
  { icon: <PeopleOutline />, text: "Manage Team", link: "/team" },
  {
    icon: <ContactsOutlined />,
    text: "contacts Information",
    link: "/contacts",
  },
  { icon: <ReceiptOutlined />, text: "Invoices Blaances", link: "/invoices" },
];
const part2 = [
  { icon: <PersonOutline />, text: "Profile Form", link: "/Form" },
  { icon: <CalendarTodayOutlined />, text: "Calender", link: "/Calender" },
  { icon: <HelpOutlineOutlined />, text: "FaQ Page", link: "/FaQ" },
];
const part3 = [
  { icon: <BarChartOutlined />, text: "Bar Chart", link: "/BarChart" },
  { icon: <PieChartOutline />, text: "Pie Chart", link: "/PieChart" },
  { icon: <TimelineOutlined />, text: "Line chart", link: "/LineChart" },
  { icon: <MapOutlined />, text: "Geography Chart", link: "/GeographyChart" },
];

interface SidebarProps {
  open: boolean;
  handleDrawerClose: () => void;
}
const Sidebarr: React.FC<SidebarProps> = ({ open, handleDrawerClose }) => {
  let location = useLocation();
  let navigate = useNavigate();
  const theme = useTheme();
  return (
    <Drawer variant="permanent" open={open}>
      <DrawerHeader>
        <IconButton onClick={handleDrawerClose}>
          {theme.direction === "rtl" ? (
            <ChevronRightIcon />
          ) : (
            <ChevronLeftIcon />
          )}
        </IconButton>
      </DrawerHeader>

      <Divider />

      <Avatar
        alt="Remy Sharp"
        src="public\assest\photo-Tarek.jpg"
        sx={{
          mx: "auto",
          height: open ? 100 : 44,
          width: open ? 100 : 44,
          transition: "0.3s",
          mt: 1,
          border: "2px solid gray",
        }}
      />
      <Typography
        sx={{ fontSize: open ? 17 : 0, transition: "0.3s" }}
        align="center"
      >
        TAREK
      </Typography>
      <Typography
        sx={{
          fontSize: open ? 15 : 0,
          transition: "0.3s",
          color: theme.palette.info.main,
          textTransform:"capitalize",
        }}
        align="center"
      >
       Project dashboard
      </Typography>
      <Divider />

      <List>
        {part1.map((index) => (
          <ListItem key={index.link} disablePadding sx={{ display: "block" }}>
            <Tooltip title={open ? null : index.text} placement="left">
              <ListItemButton
                onClick={() => {
                  navigate(index.link);
                }}
                sx={[
                  {
                    minHeight: 48,
                    px: 2.5,
                    bgcolor:
                      location.pathname === index.link
                        ? theme.palette.mode === "dark"
                          ? grey[900]
                          : grey[300]
                        : null,
                  },
                  open
                    ? {
                        justifyContent: "initial",
                      }
                    : {
                        justifyContent: "center",
                      },
                ]}
              >
                <ListItemIcon
                  sx={[
                    {
                      minWidth: 0,
                      justifyContent: "center",
                    },
                    open
                      ? {
                          mr: 3,
                        }
                      : {
                          mr: "auto",
                        },
                  ]}
                >
                  {index.icon}
                </ListItemIcon>
                <ListItemText
                  primary={index.text}
                  sx={[
                    open
                      ? {
                          opacity: 1,
                        }
                      : {
                          opacity: 0,
                        },
                  ]}
                />
              </ListItemButton>
            </Tooltip>
          </ListItem>
        ))}
      </List>

      <Divider />

      <List>
        {part2.map((index) => (
          <ListItem
            key={index.link}
            disablePadding
            sx={{
              display: "block",
              bgcolor:
                location.pathname === index.link
                  ? theme.palette.mode === "dark"
                    ? grey[900]
                    : grey[300]
                  : null,
            }}
          >
            <Tooltip title={open ? null : index.text} placement="left">
              <ListItemButton
                onClick={() => {
                  navigate(index.link);
                }}
                sx={[
                  {
                    minHeight: 48,
                    px: 2.5,
                  },
                  open
                    ? {
                        justifyContent: "initial",
                      }
                    : {
                        justifyContent: "center",
                      },
                ]}
              >
                <ListItemIcon
                  sx={[
                    {
                      minWidth: 0,
                      justifyContent: "center",
                    },
                    open
                      ? {
                          mr: 3,
                        }
                      : {
                          mr: "auto",
                        },
                  ]}
                >
                  {index.icon}
                </ListItemIcon>
                <ListItemText
                  primary={index.text}
                  sx={[
                    open
                      ? {
                          opacity: 1,
                        }
                      : {
                          opacity: 0,
                        },
                  ]}
                />
              </ListItemButton>
            </Tooltip>
          </ListItem>
        ))}
      </List>

      <Divider />
      <List>
        {part3.map((index) => (
          <ListItem
            key={index.link}
            disablePadding
            sx={{
              display: "block",
              bgcolor:
                location.pathname === index.link
                  ? theme.palette.mode === "dark"
                    ? grey[900]
                    : grey[300]
                  : null,
            }}
          >
            <Tooltip title={index.text} placement="left">
              <ListItemButton
                onClick={() => {
                  navigate(index.link);
                }}
                sx={[
                  {
                    minHeight: 48,
                    px: 2.5,
                  },
                  open
                    ? {
                        justifyContent: "initial",
                      }
                    : {
                        justifyContent: "center",
                      },
                ]}
              >
                <ListItemIcon
                  sx={[
                    {
                      minWidth: 0,
                      justifyContent: "center",
                    },
                    open
                      ? {
                          mr: 3,
                        }
                      : {
                          mr: "auto",
                        },
                  ]}
                >
                  {index.icon}
                </ListItemIcon>
                <ListItemText
                  primary={index.text}
                  sx={[
                    open
                      ? {
                          opacity: 1,
                        }
                      : {
                          opacity: 0,
                        },
                  ]}
                />
              </ListItemButton>
            </Tooltip>
          </ListItem>
        ))}
      </List>
    </Drawer>
  );
};

export default Sidebarr;
