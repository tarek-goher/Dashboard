import Bar from "./bar";

const BarChart = () => {
  return <Bar />;
};

export default BarChart;
